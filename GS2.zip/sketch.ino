#include <WiFi.h>
#include <WebServer.h>
#include <math.h>

#define POT_PIN 34

const char* ssid = "Wokwi-GUEST";
const char* password = "";

WebServer server(80);

String statusAtual = "Aguardando";
float pressaoAtual = 0.0;
float desvioAtual = 0.0;

unsigned long ultimaLeitura = 0;

float lerPressao() {
  int raw = analogRead(POT_PIN);

  // O potenciômetro simula uma pressão entre 50 e 150 kPa
  float pressao = 50.0 + (raw / 4095.0) * 100.0;

  return pressao;
}

void classificarAmbiente() {
  pressaoAtual = lerPressao();

  // Pressão ideal do habitat: 100 kPa
  desvioAtual = fabs(pressaoAtual - 100.0);

  /*
    Regras traduzidas a partir do modelo treinado no Edge Impulse:

    Seguro:
    desvio de até 10 kPa

    Alerta:
    desvio maior que 10 e até 25 kPa

    Crítico:
    desvio maior que 25 kPa
  */

  if (desvioAtual <= 10.0) {
    statusAtual = "Seguro";
  } 
  else if (desvioAtual <= 25.0) {
    statusAtual = "Alerta";
  } 
  else {
    statusAtual = "Critico";
  }

  Serial.println("-----------------------------");
  Serial.print("Pressao simulada: ");
  Serial.print(pressaoAtual, 2);
  Serial.println(" kPa");

  Serial.print("Desvio da pressao ideal: ");
  Serial.print(desvioAtual, 2);
  Serial.println(" kPa");

  Serial.print("Status do habitat: ");
  Serial.println(statusAtual);
}

String corStatus() {
  if (statusAtual == "Seguro") {
    return "#2ecc71";
  }

  if (statusAtual == "Alerta") {
    return "#f1c40f";
  }

  if (statusAtual == "Critico") {
    return "#e74c3c";
  }

  return "#95a5a6";
}

String descricaoStatus() {
  if (statusAtual == "Seguro") {
    return "Ambiente dentro dos parametros ideais para permanencia dos astronautas.";
  }

  if (statusAtual == "Alerta") {
    return "Anomalia moderada detectada. Recomenda-se verificacao do sistema atmosferico.";
  }

  if (statusAtual == "Critico") {
    return "Risco elevado. Acionar protocolo de emergencia do habitat.";
  }

  return "Aguardando leitura do sensor.";
}

void handleRoot() {
  String html = "";

  html += "<!DOCTYPE html>";
  html += "<html lang='pt-BR'>";
  html += "<head>";
  html += "<meta charset='UTF-8'>";
  html += "<meta name='viewport' content='width=device-width, initial-scale=1.0'>";
  html += "<meta http-equiv='refresh' content='2'>";
  html += "<title>Guardiao de Habitats Extremos</title>";

  html += "<style>";
  html += "body {";
  html += "font-family: Arial, sans-serif;";
  html += "background: #0b1020;";
  html += "color: white;";
  html += "text-align: center;";
  html += "padding: 40px;";
  html += "}";

  html += ".card {";
  html += "background: #161b33;";
  html += "border-radius: 20px;";
  html += "padding: 30px;";
  html += "max-width: 600px;";
  html += "margin: auto;";
  html += "box-shadow: 0 0 25px rgba(0,0,0,0.5);";
  html += "}";

  html += ".status {";
  html += "font-size: 42px;";
  html += "font-weight: bold;";
  html += "padding: 25px;";
  html += "border-radius: 15px;";
  html += "margin: 25px 0;";
  html += "color: #111;";
  html += "}";

  html += ".info {";
  html += "font-size: 22px;";
  html += "margin: 12px;";
  html += "}";

  html += ".sub {";
  html += "color: #b8c1ec;";
  html += "font-size: 16px;";
  html += "line-height: 1.5;";
  html += "}";

  html += ".ods {";
  html += "margin-top: 20px;";
  html += "font-size: 14px;";
  html += "color: #dfe6e9;";
  html += "}";
  html += "</style>";

  html += "</head>";
  html += "<body>";

  html += "<div class='card'>";
  html += "<h1>Guardiao de Habitats Extremos</h1>";
  html += "<p class='sub'>Monitoramento atmosferico de habitat lunar/marciano com TinyML e ESP32 Webserver</p>";

  html += "<div class='status' style='background:";
  html += corStatus();
  html += ";'>";
  html += statusAtual;
  html += "</div>";

  html += "<div class='info'>Pressao simulada: ";
  html += String(pressaoAtual, 2);
  html += " kPa</div>";

  html += "<div class='info'>Desvio da pressao ideal: ";
  html += String(desvioAtual, 2);
  html += " kPa</div>";

  html += "<p class='sub'>";
  html += descricaoStatus();
  html += "</p>";

  html += "<p class='ods'>Alinhamento: ODS 11 - Cidades e Comunidades Sustentaveis</p>";
  html += "<p class='sub'>A pagina atualiza automaticamente a cada 2 segundos.</p>";

  html += "</div>";

  html += "</body>";
  html += "</html>";

  server.send(200, "text/html", html);
}

void setup() {
  Serial.begin(115200);
  analogReadResolution(12);

  Serial.println("Iniciando Guardiao de Habitats Extremos...");

  WiFi.begin(ssid, password);

  Serial.print("Conectando ao WiFi");

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println();
  Serial.println("WiFi conectado!");
  Serial.print("IP do ESP32: ");
  Serial.println(WiFi.localIP());

  server.on("/", handleRoot);
  server.begin();

  Serial.println("Webserver iniciado!");
  Serial.println("Acesse o IP informado acima no navegador da rede local.");
}

void loop() {
  server.handleClient();

  if (millis() - ultimaLeitura >= 1000) {
    ultimaLeitura = millis();
    classificarAmbiente();
  }
}